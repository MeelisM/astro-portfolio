const { DynamoDBClient } = require("@aws-sdk/client-dynamodb");
const { DynamoDBDocumentClient, UpdateCommand, GetCommand } = require("@aws-sdk/lib-dynamodb");

const client = new DynamoDBClient({});
const docClient = DynamoDBDocumentClient.from(client);
const TABLE_NAME = "visitor_count";

exports.handler = async (event) => {
  if (!TABLE_NAME) {
    return {
      statusCode: 500,
      headers: { "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify({ message: "TABLE_NAME is not set." }),
    };
  }

  try {
    const increment = event.queryStringParameters?.increment === "true";

    if (increment) {
      const updateParams = {
        TableName: TABLE_NAME,
        Key: { id: "visitors" },
        UpdateExpression: "ADD #count :incr",
        ExpressionAttributeNames: { "#count": "count" },
        ExpressionAttributeValues: { ":incr": 1 },
        ReturnValues: "UPDATED_NEW",
      };

      const command = new UpdateCommand(updateParams);
      const result = await docClient.send(command);
      const count = result.Attributes?.count ?? 0;

      return {
        statusCode: 200,
        headers: {
          "Content-Type": "application/json",
          "Cache-Control": "no-cache, no-store",
        },
        body: JSON.stringify({ visitors: count }),
      };
    } else {
      const getParams = {
        TableName: TABLE_NAME,
        Key: { id: "visitors" },
      };

      const getCommand = new GetCommand(getParams);
      const result = await docClient.send(getCommand);
      const count = result.Item?.count ?? 0;

      return {
        statusCode: 200,
        headers: {
          "Content-Type": "application/json",
          "Cache-Control": "no-cache, no-store",
        },
        body: JSON.stringify({ visitors: count }),
      };
    }
  } catch (error) {
    console.error("Error:", error);
    return {
      statusCode: 500,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: "Error handling visitor count", error: error.message }),
    };
  }
};