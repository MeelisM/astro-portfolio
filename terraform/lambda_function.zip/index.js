const { DynamoDBClient } = require("@aws-sdk/client-dynamodb");
const { DynamoDBDocumentClient, UpdateCommand, GetCommand } = require("@aws-sdk/lib-dynamodb");
const client = new DynamoDBClient({});
const docClient = DynamoDBDocumentClient.from(client);
const TABLE_NAME = process.env.TABLE_NAME;
const RATE_LIMIT_WINDOW = 60 * 60;

exports.handler = async (event) => {
  if (!TABLE_NAME) {
    return {
      statusCode: 500,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Cache-Control": "no-cache",
      },
      body: JSON.stringify({ message: "TABLE_NAME is not set." }),
    };
  }

  const ip =
    event.headers["x-forwarded-for"]?.split(",")[0] ||
    event.requestContext?.identity?.sourceIp ||
    "unknown";

  try {
    const ipKey = `ip-${ip}`;
    const currentTime = Math.floor(Date.now() / 1000);

    const getParams = {
      TableName: TABLE_NAME,
      Key: { id: ipKey },
    };

    try {
      const ipResult = await docClient.send(new GetCommand(getParams));

      if (ipResult.Item) {
        const lastVisit = ipResult.Item.timestamp;
        if (currentTime - lastVisit < RATE_LIMIT_WINDOW) {
          const getCountParams = {
            TableName: TABLE_NAME,
            Key: { id: "visitors" },
          };
          const countResult = await docClient.send(new GetCommand(getCountParams));
          return {
            statusCode: 200,
            headers: {
              "Content-Type": "application/json",
              "Cache-Control": "no-cache, no-store",
              "Access-Control-Allow-Origin": "*",
            },
            body: JSON.stringify({
              visitors: countResult.Item?.count || 0,
              counted: false,
            }),
          };
        }
      }
    } catch (error) {
      console.log("IP check error or first visit:", error);
    }

    const updateIpParams = {
      TableName: TABLE_NAME,
      Key: { id: ipKey },
      UpdateExpression: "SET #ts = :time",
      ExpressionAttributeNames: {
        "#ts": "timestamp",
      },
      ExpressionAttributeValues: {
        ":time": currentTime,
      },
    };
    await docClient.send(new UpdateCommand(updateIpParams));

    const updateParams = {
      TableName: TABLE_NAME,
      Key: { id: "visitors" },
      UpdateExpression: "ADD #count :incr",
      ExpressionAttributeNames: {
        "#count": "count",
      },
      ExpressionAttributeValues: {
        ":incr": 1,
      },
      ReturnValues: "UPDATED_NEW",
    };
    const command = new UpdateCommand(updateParams);
    const result = await docClient.send(command);
    const count = result.Attributes?.count ?? 0;

    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json",
        "Cache-Control": "no-cache, no-store",
        "Access-Control-Allow-Origin": "*",
      },
      body: JSON.stringify({
        visitors: count,
        counted: true,
      }),
    };
  } catch (error) {
    console.error("Error updating visitor count:", error);
    return {
      statusCode: 500,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
      },
      body: JSON.stringify({ message: "Error updating visitor count" }),
    };
  }
};
