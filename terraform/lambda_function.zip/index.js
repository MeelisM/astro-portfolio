const { DynamoDBClient } = require("@aws-sdk/client-dynamodb");
const { DynamoDBDocumentClient, UpdateCommand } = require("@aws-sdk/lib-dynamodb");
const client = new DynamoDBClient({});
const docClient = DynamoDBDocumentClient.from(client);
const TABLE_NAME = process.env.TABLE_NAME;
const EXPECTED_SECRET = process.env.API_SECRET_HEADER;

if (!TABLE_NAME || !EXPECTED_SECRET) {
  console.error("Missing required environment variables.");
  throw new Error("TABLE_NAME and API_SECRET_HEADER must be set.");
}

exports.handler = async (event) => {
  try {
    const headers = event.headers || {};
    const secretHeader = headers["X-API-Secret"];

    if (!secretHeader || secretHeader !== EXPECTED_SECRET) {
      console.error("Unauthorized request attempt.");
      return {
        statusCode: 403,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: "Access denied!" }),
      };
    }
    const updateParams = {
      TableName: TABLE_NAME,
      Key: { id: "visitors" },
      UpdateExpression: "ADD #count :incr",
      ExpressionAttributeNames: { "#count": "count" },
      ExpressionAttributeValues: { ":incr": 1 },
      ReturnValues: "UPDATED_NEW",
    };
    const command = new UpdateCommand(updateParams);
    const result = await docClient.send(command);
    const count = result.Attributes?.count ?? 0;
    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ visitors: count }),
    };
  } catch (error) {
    console.error("Error updating visitor count:", error);
    return {
      statusCode: 500,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: "Error updating visitor count" }),
    };
  }
};
